﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Loading
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Loading))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MetroStyleManager1 = New MetroFramework.Components.MetroStyleManager()
        Me.MetroProgressBar1 = New MetroFramework.Controls.MetroProgressBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-4, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(770, 448)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'MetroStyleManager1
        '
        Me.MetroStyleManager1.OwnerForm = Me
        Me.MetroStyleManager1.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroStyleManager1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroProgressBar1
        '
        Me.MetroProgressBar1.FontSize = MetroFramework.MetroProgressBarSize.Medium
        Me.MetroProgressBar1.FontWeight = MetroFramework.MetroProgressBarWeight.Light
        Me.MetroProgressBar1.HideProgressText = True
        Me.MetroProgressBar1.Location = New System.Drawing.Point(117, 100)
        Me.MetroProgressBar1.Name = "MetroProgressBar1"
        Me.MetroProgressBar1.ProgressBarStyle = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.MetroProgressBar1.Size = New System.Drawing.Size(439, 29)
        Me.MetroProgressBar1.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroProgressBar1.StyleManager = Me.MetroStyleManager1
        Me.MetroProgressBar1.TabIndex = 1
        Me.MetroProgressBar1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MetroProgressBar1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'Timer1
        '
        '
        'Loading
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(676, 430)
        Me.Controls.Add(Me.MetroProgressBar1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Location = New System.Drawing.Point(0, 0)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Loading"
        Me.Style = MetroFramework.MetroColorStyle.Red
        Me.StyleManager = Me.MetroStyleManager1
        Me.Text = "Form1"
        Me.Theme = MetroFramework.MetroThemeStyle.Dark
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MetroStyleManager1 As MetroFramework.Components.MetroStyleManager
    Friend WithEvents MetroProgressBar1 As MetroFramework.Controls.MetroProgressBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
