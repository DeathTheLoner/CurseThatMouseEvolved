﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Game
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MetroStyleManager1 = New MetroFramework.Components.MetroStyleManager()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.Label149 = New System.Windows.Forms.Label()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.P1FINISH = New System.Windows.Forms.Label()
        Me.P1START = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MetroStyleManager1
        '
        Me.MetroStyleManager1.OwnerForm = Me
        Me.MetroStyleManager1.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroStyleManager1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'Label150
        '
        Me.Label150.BackColor = System.Drawing.Color.Red
        Me.Label150.Location = New System.Drawing.Point(968, 208)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(51, 23)
        Me.Label150.TabIndex = 177
        '
        'Label149
        '
        Me.Label149.BackColor = System.Drawing.Color.Red
        Me.Label149.Location = New System.Drawing.Point(728, 189)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(63, 23)
        Me.Label149.TabIndex = 176
        '
        'Label148
        '
        Me.Label148.BackColor = System.Drawing.Color.Red
        Me.Label148.Location = New System.Drawing.Point(792, 395)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(49, 27)
        Me.Label148.TabIndex = 175
        '
        'Label147
        '
        Me.Label147.BackColor = System.Drawing.Color.Red
        Me.Label147.Location = New System.Drawing.Point(0, -8)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(1158, 10)
        Me.Label147.TabIndex = 174
        '
        'Label146
        '
        Me.Label146.BackColor = System.Drawing.Color.Red
        Me.Label146.Location = New System.Drawing.Point(-25, 0)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(30, 616)
        Me.Label146.TabIndex = 173
        '
        'Label145
        '
        Me.Label145.BackColor = System.Drawing.Color.Red
        Me.Label145.Location = New System.Drawing.Point(0, 607)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(934, 10)
        Me.Label145.TabIndex = 172
        '
        'Label144
        '
        Me.Label144.BackColor = System.Drawing.Color.Red
        Me.Label144.Location = New System.Drawing.Point(1143, 0)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(32, 631)
        Me.Label144.TabIndex = 171
        '
        'Label143
        '
        Me.Label143.BackColor = System.Drawing.Color.Red
        Me.Label143.Location = New System.Drawing.Point(1143, 535)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(14, 74)
        Me.Label143.TabIndex = 170
        '
        'Label142
        '
        Me.Label142.BackColor = System.Drawing.Color.Red
        Me.Label142.Location = New System.Drawing.Point(1019, 608)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(136, 23)
        Me.Label142.TabIndex = 169
        '
        'Label141
        '
        Me.Label141.BackColor = System.Drawing.Color.Red
        Me.Label141.Location = New System.Drawing.Point(118, 0)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(68, 23)
        Me.Label141.TabIndex = 168
        '
        'Label140
        '
        Me.Label140.BackColor = System.Drawing.Color.Red
        Me.Label140.Location = New System.Drawing.Point(792, 287)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(49, 23)
        Me.Label140.TabIndex = 165
        '
        'Label138
        '
        Me.Label138.BackColor = System.Drawing.Color.Red
        Me.Label138.Location = New System.Drawing.Point(1071, 230)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(71, 23)
        Me.Label138.TabIndex = 164
        '
        'Label134
        '
        Me.Label134.BackColor = System.Drawing.Color.Red
        Me.Label134.Location = New System.Drawing.Point(1019, 141)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(103, 23)
        Me.Label134.TabIndex = 163
        '
        'Label132
        '
        Me.Label132.BackColor = System.Drawing.Color.Red
        Me.Label132.Location = New System.Drawing.Point(1071, 0)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(27, 69)
        Me.Label132.TabIndex = 162
        '
        'Label77
        '
        Me.Label77.BackColor = System.Drawing.Color.Red
        Me.Label77.Location = New System.Drawing.Point(1019, 186)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(103, 23)
        Me.Label77.TabIndex = 161
        '
        'Label137
        '
        Me.Label137.BackColor = System.Drawing.Color.Red
        Me.Label137.Location = New System.Drawing.Point(1019, 101)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(27, 108)
        Me.Label137.TabIndex = 160
        '
        'Label139
        '
        Me.Label139.BackColor = System.Drawing.Color.Red
        Me.Label139.Location = New System.Drawing.Point(713, 281)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(27, 108)
        Me.Label139.TabIndex = 159
        '
        'Label135
        '
        Me.Label135.BackColor = System.Drawing.Color.Red
        Me.Label135.Location = New System.Drawing.Point(891, 40)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(106, 23)
        Me.Label135.TabIndex = 158
        '
        'Label136
        '
        Me.Label136.BackColor = System.Drawing.Color.Red
        Me.Label136.Location = New System.Drawing.Point(480, 465)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(80, 23)
        Me.Label136.TabIndex = 157
        '
        'Label133
        '
        Me.Label133.BackColor = System.Drawing.Color.Red
        Me.Label133.Location = New System.Drawing.Point(1019, 94)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(103, 23)
        Me.Label133.TabIndex = 154
        '
        'Label128
        '
        Me.Label128.BackColor = System.Drawing.Color.Red
        Me.Label128.Location = New System.Drawing.Point(566, 558)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(27, 58)
        Me.Label128.TabIndex = 151
        '
        'Label129
        '
        Me.Label129.BackColor = System.Drawing.Color.Red
        Me.Label129.Location = New System.Drawing.Point(972, 11)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(27, 69)
        Me.Label129.TabIndex = 150
        '
        'Label130
        '
        Me.Label130.BackColor = System.Drawing.Color.Red
        Me.Label130.Location = New System.Drawing.Point(1019, 40)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(27, 108)
        Me.Label130.TabIndex = 149
        '
        'Label131
        '
        Me.Label131.BackColor = System.Drawing.Color.Red
        Me.Label131.Location = New System.Drawing.Point(943, 189)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(27, 108)
        Me.Label131.TabIndex = 148
        '
        'Label126
        '
        Me.Label126.BackColor = System.Drawing.Color.Red
        Me.Label126.Location = New System.Drawing.Point(836, 0)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(27, 108)
        Me.Label126.TabIndex = 147
        '
        'Label127
        '
        Me.Label127.BackColor = System.Drawing.Color.Red
        Me.Label127.Location = New System.Drawing.Point(972, 101)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(27, 108)
        Me.Label127.TabIndex = 146
        '
        'Label125
        '
        Me.Label125.BackColor = System.Drawing.Color.Red
        Me.Label125.Location = New System.Drawing.Point(1005, 248)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(27, 132)
        Me.Label125.TabIndex = 145
        '
        'Label117
        '
        Me.Label117.BackColor = System.Drawing.Color.Red
        Me.Label117.Location = New System.Drawing.Point(782, 234)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(113, 23)
        Me.Label117.TabIndex = 144
        '
        'Label118
        '
        Me.Label118.BackColor = System.Drawing.Color.Red
        Me.Label118.Location = New System.Drawing.Point(1057, 529)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(88, 23)
        Me.Label118.TabIndex = 143
        '
        'Label119
        '
        Me.Label119.BackColor = System.Drawing.Color.Red
        Me.Label119.Location = New System.Drawing.Point(836, 186)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(113, 23)
        Me.Label119.TabIndex = 142
        '
        'Label120
        '
        Me.Label120.BackColor = System.Drawing.Color.Red
        Me.Label120.Location = New System.Drawing.Point(888, 492)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(226, 23)
        Me.Label120.TabIndex = 141
        '
        'Label121
        '
        Me.Label121.BackColor = System.Drawing.Color.Red
        Me.Label121.Location = New System.Drawing.Point(685, 57)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(113, 23)
        Me.Label121.TabIndex = 140
        '
        'Label122
        '
        Me.Label122.BackColor = System.Drawing.Color.Red
        Me.Label122.Location = New System.Drawing.Point(836, 136)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(113, 23)
        Me.Label122.TabIndex = 139
        '
        'Label123
        '
        Me.Label123.BackColor = System.Drawing.Color.Red
        Me.Label123.Location = New System.Drawing.Point(933, 535)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(100, 23)
        Me.Label123.TabIndex = 138
        '
        'Label124
        '
        Me.Label124.BackColor = System.Drawing.Color.Red
        Me.Label124.Location = New System.Drawing.Point(984, 449)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(113, 23)
        Me.Label124.TabIndex = 137
        '
        'Label110
        '
        Me.Label110.BackColor = System.Drawing.Color.Red
        Me.Label110.Location = New System.Drawing.Point(728, 512)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(27, 101)
        Me.Label110.TabIndex = 136
        '
        'Label111
        '
        Me.Label111.BackColor = System.Drawing.Color.Red
        Me.Label111.Location = New System.Drawing.Point(1071, 364)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(27, 108)
        Me.Label111.TabIndex = 135
        '
        'Label112
        '
        Me.Label112.BackColor = System.Drawing.Color.Red
        Me.Label112.Location = New System.Drawing.Point(260, 512)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(27, 108)
        Me.Label112.TabIndex = 134
        '
        'Label113
        '
        Me.Label113.BackColor = System.Drawing.Color.Red
        Me.Label113.Location = New System.Drawing.Point(782, 136)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(27, 108)
        Me.Label113.TabIndex = 133
        '
        'Label114
        '
        Me.Label114.BackColor = System.Drawing.Color.Red
        Me.Label114.Location = New System.Drawing.Point(888, 287)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(27, 108)
        Me.Label114.TabIndex = 132
        '
        'Label115
        '
        Me.Label115.BackColor = System.Drawing.Color.Red
        Me.Label115.Location = New System.Drawing.Point(888, 395)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(27, 108)
        Me.Label115.TabIndex = 131
        '
        'Label116
        '
        Me.Label116.BackColor = System.Drawing.Color.Red
        Me.Label116.Location = New System.Drawing.Point(782, 17)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(27, 100)
        Me.Label116.TabIndex = 130
        '
        'Label109
        '
        Me.Label109.BackColor = System.Drawing.Color.Red
        Me.Label109.Location = New System.Drawing.Point(120, 507)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(27, 108)
        Me.Label109.TabIndex = 129
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Controls.Add(Me.Label150)
        Me.Panel1.Controls.Add(Me.Label149)
        Me.Panel1.Controls.Add(Me.Label148)
        Me.Panel1.Controls.Add(Me.Label147)
        Me.Panel1.Controls.Add(Me.Label146)
        Me.Panel1.Controls.Add(Me.Label145)
        Me.Panel1.Controls.Add(Me.Label144)
        Me.Panel1.Controls.Add(Me.Label143)
        Me.Panel1.Controls.Add(Me.Label142)
        Me.Panel1.Controls.Add(Me.Label141)
        Me.Panel1.Controls.Add(Me.P1FINISH)
        Me.Panel1.Controls.Add(Me.P1START)
        Me.Panel1.Controls.Add(Me.Label140)
        Me.Panel1.Controls.Add(Me.Label138)
        Me.Panel1.Controls.Add(Me.Label134)
        Me.Panel1.Controls.Add(Me.Label132)
        Me.Panel1.Controls.Add(Me.Label77)
        Me.Panel1.Controls.Add(Me.Label137)
        Me.Panel1.Controls.Add(Me.Label139)
        Me.Panel1.Controls.Add(Me.Label135)
        Me.Panel1.Controls.Add(Me.Label136)
        Me.Panel1.Controls.Add(Me.Label133)
        Me.Panel1.Controls.Add(Me.Label128)
        Me.Panel1.Controls.Add(Me.Label129)
        Me.Panel1.Controls.Add(Me.Label130)
        Me.Panel1.Controls.Add(Me.Label131)
        Me.Panel1.Controls.Add(Me.Label126)
        Me.Panel1.Controls.Add(Me.Label127)
        Me.Panel1.Controls.Add(Me.Label125)
        Me.Panel1.Controls.Add(Me.Label117)
        Me.Panel1.Controls.Add(Me.Label118)
        Me.Panel1.Controls.Add(Me.Label119)
        Me.Panel1.Controls.Add(Me.Label120)
        Me.Panel1.Controls.Add(Me.Label121)
        Me.Panel1.Controls.Add(Me.Label122)
        Me.Panel1.Controls.Add(Me.Label123)
        Me.Panel1.Controls.Add(Me.Label124)
        Me.Panel1.Controls.Add(Me.Label110)
        Me.Panel1.Controls.Add(Me.Label111)
        Me.Panel1.Controls.Add(Me.Label112)
        Me.Panel1.Controls.Add(Me.Label113)
        Me.Panel1.Controls.Add(Me.Label114)
        Me.Panel1.Controls.Add(Me.Label115)
        Me.Panel1.Controls.Add(Me.Label116)
        Me.Panel1.Controls.Add(Me.Label109)
        Me.Panel1.Controls.Add(Me.Label108)
        Me.Panel1.Controls.Add(Me.Label107)
        Me.Panel1.Controls.Add(Me.Label106)
        Me.Panel1.Controls.Add(Me.Label105)
        Me.Panel1.Controls.Add(Me.Label104)
        Me.Panel1.Controls.Add(Me.Label101)
        Me.Panel1.Controls.Add(Me.Label100)
        Me.Panel1.Controls.Add(Me.Label102)
        Me.Panel1.Controls.Add(Me.Label103)
        Me.Panel1.Controls.Add(Me.Label89)
        Me.Panel1.Controls.Add(Me.Label90)
        Me.Panel1.Controls.Add(Me.Label91)
        Me.Panel1.Controls.Add(Me.Label92)
        Me.Panel1.Controls.Add(Me.Label93)
        Me.Panel1.Controls.Add(Me.Label94)
        Me.Panel1.Controls.Add(Me.Label95)
        Me.Panel1.Controls.Add(Me.Label96)
        Me.Panel1.Controls.Add(Me.Label97)
        Me.Panel1.Controls.Add(Me.Label98)
        Me.Panel1.Controls.Add(Me.Label99)
        Me.Panel1.Controls.Add(Me.Label88)
        Me.Panel1.Controls.Add(Me.Label87)
        Me.Panel1.Controls.Add(Me.Label86)
        Me.Panel1.Controls.Add(Me.Label85)
        Me.Panel1.Controls.Add(Me.Label84)
        Me.Panel1.Controls.Add(Me.Label83)
        Me.Panel1.Controls.Add(Me.Label82)
        Me.Panel1.Controls.Add(Me.Label81)
        Me.Panel1.Controls.Add(Me.Label79)
        Me.Panel1.Controls.Add(Me.Label73)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label36)
        Me.Panel1.Controls.Add(Me.Label41)
        Me.Panel1.Controls.Add(Me.Label42)
        Me.Panel1.Controls.Add(Me.Label43)
        Me.Panel1.Controls.Add(Me.Label44)
        Me.Panel1.Controls.Add(Me.Label45)
        Me.Panel1.Controls.Add(Me.Label72)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label27)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label67)
        Me.Panel1.Controls.Add(Me.Label68)
        Me.Panel1.Controls.Add(Me.Label69)
        Me.Panel1.Controls.Add(Me.Label70)
        Me.Panel1.Controls.Add(Me.Label71)
        Me.Panel1.Controls.Add(Me.Label74)
        Me.Panel1.Controls.Add(Me.Label75)
        Me.Panel1.Controls.Add(Me.Label76)
        Me.Panel1.Controls.Add(Me.Label78)
        Me.Panel1.Controls.Add(Me.Label80)
        Me.Panel1.Controls.Add(Me.Label51)
        Me.Panel1.Controls.Add(Me.Label52)
        Me.Panel1.Controls.Add(Me.Label53)
        Me.Panel1.Controls.Add(Me.Label54)
        Me.Panel1.Controls.Add(Me.Label55)
        Me.Panel1.Controls.Add(Me.Label56)
        Me.Panel1.Controls.Add(Me.Label57)
        Me.Panel1.Controls.Add(Me.Label58)
        Me.Panel1.Controls.Add(Me.Label59)
        Me.Panel1.Controls.Add(Me.Label60)
        Me.Panel1.Controls.Add(Me.Label61)
        Me.Panel1.Controls.Add(Me.Label62)
        Me.Panel1.Controls.Add(Me.Label63)
        Me.Panel1.Controls.Add(Me.Label64)
        Me.Panel1.Controls.Add(Me.Label65)
        Me.Panel1.Controls.Add(Me.Label66)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label37)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.Label39)
        Me.Panel1.Controls.Add(Me.Label40)
        Me.Panel1.Controls.Add(Me.Label46)
        Me.Panel1.Controls.Add(Me.Label47)
        Me.Panel1.Controls.Add(Me.Label48)
        Me.Panel1.Controls.Add(Me.Label49)
        Me.Panel1.Controls.Add(Me.Label50)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(1, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1154, 619)
        Me.Panel1.TabIndex = 3
        '
        'P1FINISH
        '
        Me.P1FINISH.AutoSize = True
        Me.P1FINISH.BackColor = System.Drawing.Color.White
        Me.P1FINISH.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.P1FINISH.Location = New System.Drawing.Point(1056, 574)
        Me.P1FINISH.Name = "P1FINISH"
        Me.P1FINISH.Size = New System.Drawing.Size(69, 20)
        Me.P1FINISH.TabIndex = 167
        Me.P1FINISH.Text = "FINISH"
        '
        'P1START
        '
        Me.P1START.AutoSize = True
        Me.P1START.BackColor = System.Drawing.Color.White
        Me.P1START.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.P1START.Location = New System.Drawing.Point(16, 17)
        Me.P1START.Name = "P1START"
        Me.P1START.Size = New System.Drawing.Size(66, 20)
        Me.P1START.TabIndex = 166
        Me.P1START.Text = "START"
        '
        'Label108
        '
        Me.Label108.BackColor = System.Drawing.Color.Red
        Me.Label108.Location = New System.Drawing.Point(979, 395)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(27, 77)
        Me.Label108.TabIndex = 128
        '
        'Label107
        '
        Me.Label107.BackColor = System.Drawing.Color.Red
        Me.Label107.Location = New System.Drawing.Point(836, 136)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(27, 108)
        Me.Label107.TabIndex = 127
        '
        'Label106
        '
        Me.Label106.BackColor = System.Drawing.Color.Red
        Me.Label106.Location = New System.Drawing.Point(1071, 230)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(27, 108)
        Me.Label106.TabIndex = 126
        '
        'Label105
        '
        Me.Label105.BackColor = System.Drawing.Color.Red
        Me.Label105.Location = New System.Drawing.Point(888, 535)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(27, 99)
        Me.Label105.TabIndex = 125
        '
        'Label104
        '
        Me.Label104.BackColor = System.Drawing.Color.Red
        Me.Label104.Location = New System.Drawing.Point(943, 231)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(27, 123)
        Me.Label104.TabIndex = 124
        '
        'Label101
        '
        Me.Label101.BackColor = System.Drawing.Color.Red
        Me.Label101.Location = New System.Drawing.Point(1019, 558)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(14, 53)
        Me.Label101.TabIndex = 123
        '
        'Label100
        '
        Me.Label100.BackColor = System.Drawing.Color.Red
        Me.Label100.Location = New System.Drawing.Point(728, 461)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(113, 23)
        Me.Label100.TabIndex = 122
        '
        'Label102
        '
        Me.Label102.BackColor = System.Drawing.Color.Red
        Me.Label102.Location = New System.Drawing.Point(728, 461)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(27, 114)
        Me.Label102.TabIndex = 120
        '
        'Label103
        '
        Me.Label103.BackColor = System.Drawing.Color.Red
        Me.Label103.Location = New System.Drawing.Point(772, 422)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(27, 108)
        Me.Label103.TabIndex = 119
        '
        'Label89
        '
        Me.Label89.BackColor = System.Drawing.Color.Red
        Me.Label89.Location = New System.Drawing.Point(317, 257)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(113, 23)
        Me.Label89.TabIndex = 118
        '
        'Label90
        '
        Me.Label90.BackColor = System.Drawing.Color.Red
        Me.Label90.Location = New System.Drawing.Point(480, 550)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(113, 23)
        Me.Label90.TabIndex = 117
        '
        'Label91
        '
        Me.Label91.BackColor = System.Drawing.Color.Red
        Me.Label91.Location = New System.Drawing.Point(566, 372)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(113, 23)
        Me.Label91.TabIndex = 116
        '
        'Label92
        '
        Me.Label92.BackColor = System.Drawing.Color.Red
        Me.Label92.Location = New System.Drawing.Point(627, 331)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(113, 23)
        Me.Label92.TabIndex = 115
        '
        'Label93
        '
        Me.Label93.BackColor = System.Drawing.Color.Red
        Me.Label93.Location = New System.Drawing.Point(615, 556)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(140, 23)
        Me.Label93.TabIndex = 114
        '
        'Label94
        '
        Me.Label94.BackColor = System.Drawing.Color.Red
        Me.Label94.Location = New System.Drawing.Point(836, 372)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(113, 23)
        Me.Label94.TabIndex = 113
        '
        'Label95
        '
        Me.Label95.BackColor = System.Drawing.Color.Red
        Me.Label95.Location = New System.Drawing.Point(642, 281)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(113, 23)
        Me.Label95.TabIndex = 112
        '
        'Label96
        '
        Me.Label96.BackColor = System.Drawing.Color.Red
        Me.Label96.Location = New System.Drawing.Point(1035, 395)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(113, 23)
        Me.Label96.TabIndex = 111
        '
        'Label97
        '
        Me.Label97.BackColor = System.Drawing.Color.Red
        Me.Label97.Location = New System.Drawing.Point(836, 94)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(113, 23)
        Me.Label97.TabIndex = 110
        '
        'Label98
        '
        Me.Label98.BackColor = System.Drawing.Color.Red
        Me.Label98.Location = New System.Drawing.Point(933, 535)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(100, 23)
        Me.Label98.TabIndex = 109
        '
        'Label99
        '
        Me.Label99.BackColor = System.Drawing.Color.Red
        Me.Label99.Location = New System.Drawing.Point(933, 449)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(90, 23)
        Me.Label99.TabIndex = 108
        '
        'Label88
        '
        Me.Label88.BackColor = System.Drawing.Color.Red
        Me.Label88.Location = New System.Drawing.Point(317, 454)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(113, 23)
        Me.Label88.TabIndex = 107
        '
        'Label87
        '
        Me.Label87.BackColor = System.Drawing.Color.Red
        Me.Label87.Location = New System.Drawing.Point(585, 507)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(113, 23)
        Me.Label87.TabIndex = 106
        '
        'Label86
        '
        Me.Label86.BackColor = System.Drawing.Color.Red
        Me.Label86.Location = New System.Drawing.Point(653, 461)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(113, 23)
        Me.Label86.TabIndex = 105
        '
        'Label85
        '
        Me.Label85.BackColor = System.Drawing.Color.Red
        Me.Label85.Location = New System.Drawing.Point(562, 331)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(113, 23)
        Me.Label85.TabIndex = 104
        '
        'Label84
        '
        Me.Label84.BackColor = System.Drawing.Color.Red
        Me.Label84.Location = New System.Drawing.Point(727, 555)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(124, 23)
        Me.Label84.TabIndex = 103
        '
        'Label83
        '
        Me.Label83.BackColor = System.Drawing.Color.Red
        Me.Label83.Location = New System.Drawing.Point(642, 234)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(113, 23)
        Me.Label83.TabIndex = 102
        '
        'Label82
        '
        Me.Label82.BackColor = System.Drawing.Color.Red
        Me.Label82.Location = New System.Drawing.Point(933, 591)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(100, 23)
        Me.Label82.TabIndex = 101
        '
        'Label81
        '
        Me.Label81.BackColor = System.Drawing.Color.Red
        Me.Label81.Location = New System.Drawing.Point(870, 186)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(113, 23)
        Me.Label81.TabIndex = 100
        '
        'Label79
        '
        Me.Label79.BackColor = System.Drawing.Color.Red
        Me.Label79.Location = New System.Drawing.Point(943, 231)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(103, 23)
        Me.Label79.TabIndex = 99
        '
        'Label73
        '
        Me.Label73.BackColor = System.Drawing.Color.Red
        Me.Label73.Location = New System.Drawing.Point(363, 340)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(113, 23)
        Me.Label73.TabIndex = 97
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.Red
        Me.Label34.Location = New System.Drawing.Point(506, 340)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(27, 108)
        Me.Label34.TabIndex = 96
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(533, 422)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(27, 108)
        Me.Label36.TabIndex = 95
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.Red
        Me.Label41.Location = New System.Drawing.Point(639, 418)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(27, 108)
        Me.Label41.TabIndex = 94
        '
        'Label42
        '
        Me.Label42.BackColor = System.Drawing.Color.Red
        Me.Label42.Location = New System.Drawing.Point(451, 257)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(52, 23)
        Me.Label42.TabIndex = 93
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.Red
        Me.Label43.Location = New System.Drawing.Point(713, 377)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(27, 100)
        Me.Label43.TabIndex = 92
        '
        'Label44
        '
        Me.Label44.BackColor = System.Drawing.Color.Red
        Me.Label44.Location = New System.Drawing.Point(771, 287)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(27, 108)
        Me.Label44.TabIndex = 91
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.Color.Red
        Me.Label45.Location = New System.Drawing.Point(836, 287)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(27, 108)
        Me.Label45.TabIndex = 90
        '
        'Label72
        '
        Me.Label72.BackColor = System.Drawing.Color.Red
        Me.Label72.Location = New System.Drawing.Point(728, 103)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(27, 108)
        Me.Label72.TabIndex = 89
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.Red
        Me.Label30.Location = New System.Drawing.Point(522, 189)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(27, 91)
        Me.Label30.TabIndex = 88
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.Red
        Me.Label28.Location = New System.Drawing.Point(452, 340)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(27, 108)
        Me.Label28.TabIndex = 87
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.Red
        Me.Label27.Location = New System.Drawing.Point(403, 340)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(27, 88)
        Me.Label27.TabIndex = 86
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Red
        Me.Label26.Location = New System.Drawing.Point(480, 465)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(27, 108)
        Me.Label26.TabIndex = 85
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Red
        Me.Label25.Location = New System.Drawing.Point(585, 386)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(27, 98)
        Me.Label25.TabIndex = 84
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Red
        Me.Label20.Location = New System.Drawing.Point(575, 230)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(27, 90)
        Me.Label20.TabIndex = 83
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Red
        Me.Label19.Location = New System.Drawing.Point(631, 189)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(27, 115)
        Me.Label19.TabIndex = 82
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(489, 297)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(113, 23)
        Me.Label11.TabIndex = 81
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(836, 422)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 108)
        Me.Label2.TabIndex = 80
        '
        'Label67
        '
        Me.Label67.BackColor = System.Drawing.Color.Red
        Me.Label67.Location = New System.Drawing.Point(284, 101)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(27, 133)
        Me.Label67.TabIndex = 79
        '
        'Label68
        '
        Me.Label68.BackColor = System.Drawing.Color.Red
        Me.Label68.Location = New System.Drawing.Point(506, 28)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(27, 108)
        Me.Label68.TabIndex = 78
        '
        'Label69
        '
        Me.Label69.BackColor = System.Drawing.Color.Red
        Me.Label69.Location = New System.Drawing.Point(506, 27)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(27, 108)
        Me.Label69.TabIndex = 77
        '
        'Label70
        '
        Me.Label70.BackColor = System.Drawing.Color.Red
        Me.Label70.Location = New System.Drawing.Point(386, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(27, 156)
        Me.Label70.TabIndex = 76
        '
        'Label71
        '
        Me.Label71.BackColor = System.Drawing.Color.Red
        Me.Label71.Location = New System.Drawing.Point(332, 51)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(27, 125)
        Me.Label71.TabIndex = 75
        '
        'Label74
        '
        Me.Label74.BackColor = System.Drawing.Color.Red
        Me.Label74.Location = New System.Drawing.Point(300, 201)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(113, 23)
        Me.Label74.TabIndex = 72
        '
        'Label75
        '
        Me.Label75.BackColor = System.Drawing.Color.Red
        Me.Label75.Location = New System.Drawing.Point(452, 136)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(81, 23)
        Me.Label75.TabIndex = 71
        '
        'Label76
        '
        Me.Label76.BackColor = System.Drawing.Color.Red
        Me.Label76.Location = New System.Drawing.Point(343, 298)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(113, 23)
        Me.Label76.TabIndex = 70
        '
        'Label78
        '
        Me.Label78.BackColor = System.Drawing.Color.Red
        Me.Label78.Location = New System.Drawing.Point(449, 136)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(27, 101)
        Me.Label78.TabIndex = 68
        '
        'Label80
        '
        Me.Label80.BackColor = System.Drawing.Color.Red
        Me.Label80.Location = New System.Drawing.Point(260, 51)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(89, 23)
        Me.Label80.TabIndex = 66
        '
        'Label51
        '
        Me.Label51.BackColor = System.Drawing.Color.Red
        Me.Label51.Location = New System.Drawing.Point(175, 149)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(27, 108)
        Me.Label51.TabIndex = 65
        '
        'Label52
        '
        Me.Label52.BackColor = System.Drawing.Color.Red
        Me.Label52.Location = New System.Drawing.Point(227, 51)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(27, 108)
        Me.Label52.TabIndex = 64
        '
        'Label53
        '
        Me.Label53.BackColor = System.Drawing.Color.Red
        Me.Label53.Location = New System.Drawing.Point(317, 211)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(27, 69)
        Me.Label53.TabIndex = 63
        '
        'Label54
        '
        Me.Label54.BackColor = System.Drawing.Color.Red
        Me.Label54.Location = New System.Drawing.Point(161, 23)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(27, 94)
        Me.Label54.TabIndex = 62
        '
        'Label55
        '
        Me.Label55.BackColor = System.Drawing.Color.Red
        Me.Label55.Location = New System.Drawing.Point(19, 101)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(27, 190)
        Me.Label55.TabIndex = 61
        '
        'Label56
        '
        Me.Label56.BackColor = System.Drawing.Color.Red
        Me.Label56.Location = New System.Drawing.Point(68, 56)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(27, 108)
        Me.Label56.TabIndex = 60
        '
        'Label57
        '
        Me.Label57.BackColor = System.Drawing.Color.Red
        Me.Label57.Location = New System.Drawing.Point(67, 231)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(27, 108)
        Me.Label57.TabIndex = 59
        '
        'Label58
        '
        Me.Label58.BackColor = System.Drawing.Color.Red
        Me.Label58.Location = New System.Drawing.Point(-3, 313)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(97, 26)
        Me.Label58.TabIndex = 58
        '
        'Label59
        '
        Me.Label59.BackColor = System.Drawing.Color.Red
        Me.Label59.Location = New System.Drawing.Point(506, 188)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(96, 23)
        Me.Label59.TabIndex = 57
        '
        'Label60
        '
        Me.Label60.BackColor = System.Drawing.Color.Red
        Me.Label60.Location = New System.Drawing.Point(600, 188)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(100, 23)
        Me.Label60.TabIndex = 56
        '
        'Label61
        '
        Me.Label61.BackColor = System.Drawing.Color.Red
        Me.Label61.Location = New System.Drawing.Point(231, 211)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(113, 23)
        Me.Label61.TabIndex = 55
        '
        'Label62
        '
        Me.Label62.BackColor = System.Drawing.Color.Red
        Me.Label62.Location = New System.Drawing.Point(231, 298)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(113, 23)
        Me.Label62.TabIndex = 54
        '
        'Label63
        '
        Me.Label63.BackColor = System.Drawing.Color.Red
        Me.Label63.Location = New System.Drawing.Point(522, 27)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(113, 23)
        Me.Label63.TabIndex = 53
        '
        'Label64
        '
        Me.Label64.BackColor = System.Drawing.Color.Red
        Me.Label64.Location = New System.Drawing.Point(118, 298)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(113, 23)
        Me.Label64.TabIndex = 52
        '
        'Label65
        '
        Me.Label65.BackColor = System.Drawing.Color.Red
        Me.Label65.Location = New System.Drawing.Point(20, 188)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(129, 23)
        Me.Label65.TabIndex = 51
        '
        'Label66
        '
        Me.Label66.BackColor = System.Drawing.Color.Red
        Me.Label66.Location = New System.Drawing.Point(279, 257)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(113, 23)
        Me.Label66.TabIndex = 50
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.Red
        Me.Label35.Location = New System.Drawing.Point(430, 503)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(27, 113)
        Me.Label35.TabIndex = 49
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.Red
        Me.Label37.Location = New System.Drawing.Point(120, 493)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(27, 92)
        Me.Label37.TabIndex = 47
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.Red
        Me.Label38.Location = New System.Drawing.Point(296, 311)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(27, 69)
        Me.Label38.TabIndex = 46
        '
        'Label39
        '
        Me.Label39.BackColor = System.Drawing.Color.Red
        Me.Label39.Location = New System.Drawing.Point(19, 359)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(27, 108)
        Me.Label39.TabIndex = 45
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.Red
        Me.Label40.Location = New System.Drawing.Point(449, 40)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(27, 108)
        Me.Label40.TabIndex = 44
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.Color.Red
        Me.Label46.Location = New System.Drawing.Point(68, 113)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(65, 23)
        Me.Label46.TabIndex = 38
        '
        'Label47
        '
        Me.Label47.BackColor = System.Drawing.Color.Red
        Me.Label47.Location = New System.Drawing.Point(178, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(214, 23)
        Me.Label47.TabIndex = 37
        '
        'Label48
        '
        Me.Label48.BackColor = System.Drawing.Color.Red
        Me.Label48.Location = New System.Drawing.Point(210, 409)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(113, 23)
        Me.Label48.TabIndex = 36
        '
        'Label49
        '
        Me.Label49.BackColor = System.Drawing.Color.Red
        Me.Label49.Location = New System.Drawing.Point(566, 74)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(113, 23)
        Me.Label49.TabIndex = 35
        '
        'Label50
        '
        Me.Label50.BackColor = System.Drawing.Color.Red
        Me.Label50.Location = New System.Drawing.Point(287, 503)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(113, 23)
        Me.Label50.TabIndex = 34
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Red
        Me.Label21.Location = New System.Drawing.Point(260, 503)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(27, 70)
        Me.Label21.TabIndex = 31
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(161, 340)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(27, 132)
        Me.Label22.TabIndex = 30
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(71, 489)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(27, 108)
        Me.Label23.TabIndex = 29
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Red
        Me.Label24.Location = New System.Drawing.Point(621, 80)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(27, 84)
        Me.Label24.TabIndex = 28
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.Red
        Me.Label29.Location = New System.Drawing.Point(260, 562)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(141, 23)
        Me.Label29.TabIndex = 23
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.Red
        Me.Label31.Location = New System.Drawing.Point(260, 454)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(113, 23)
        Me.Label31.TabIndex = 21
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(386, 153)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(90, 23)
        Me.Label32.TabIndex = 20
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.Red
        Me.Label33.Location = New System.Drawing.Point(120, 492)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(113, 23)
        Me.Label33.TabIndex = 19
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.Red
        Me.Label18.Location = New System.Drawing.Point(346, 340)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(27, 92)
        Me.Label18.TabIndex = 17
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Red
        Me.Label17.Location = New System.Drawing.Point(566, 74)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(27, 114)
        Me.Label17.TabIndex = 16
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(210, 422)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(27, 93)
        Me.Label16.TabIndex = 15
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Red
        Me.Label15.Location = New System.Drawing.Point(23, 489)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(27, 108)
        Me.Label15.TabIndex = 14
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Red
        Me.Label14.Location = New System.Drawing.Point(231, 179)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(27, 101)
        Me.Label14.TabIndex = 13
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Red
        Me.Label13.Location = New System.Drawing.Point(673, 28)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(27, 108)
        Me.Label13.TabIndex = 12
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(161, 136)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(93, 23)
        Me.Label12.TabIndex = 11
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(68, 407)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(113, 23)
        Me.Label10.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(120, 51)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 23)
        Me.Label9.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(175, 562)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 23)
        Me.Label8.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(210, 358)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 23)
        Me.Label7.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(19, 449)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(113, 23)
        Me.Label6.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(213, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(122, 23)
        Me.Label5.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(118, 248)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 23)
        Me.Label4.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(19, 359)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(113, 23)
        Me.Label3.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(-3, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 23)
        Me.Label1.TabIndex = 0
        '
        'Timer1
        '
        '
        'Game
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1152, 617)
        Me.Controls.Add(Me.Panel1)
        Me.Location = New System.Drawing.Point(0, 0)
        Me.Name = "Game"
        Me.Style = MetroFramework.MetroColorStyle.Red
        Me.StyleManager = Me.MetroStyleManager1
        Me.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MetroStyleManager1 As MetroFramework.Components.MetroStyleManager
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label150 As System.Windows.Forms.Label
    Friend WithEvents Label149 As System.Windows.Forms.Label
    Friend WithEvents Label148 As System.Windows.Forms.Label
    Friend WithEvents Label147 As System.Windows.Forms.Label
    Friend WithEvents Label146 As System.Windows.Forms.Label
    Friend WithEvents Label145 As System.Windows.Forms.Label
    Friend WithEvents Label144 As System.Windows.Forms.Label
    Friend WithEvents Label143 As System.Windows.Forms.Label
    Friend WithEvents Label142 As System.Windows.Forms.Label
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents P1FINISH As System.Windows.Forms.Label
    Friend WithEvents P1START As System.Windows.Forms.Label
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents Label136 As System.Windows.Forms.Label
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
