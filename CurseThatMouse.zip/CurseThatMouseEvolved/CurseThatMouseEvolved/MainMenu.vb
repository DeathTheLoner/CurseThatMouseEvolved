﻿''Original Owner DeathTheLoner / Lucas Andrews -- LEAVE THIS OR YOU ARE LEECHING ME

Public Class MainMenu

    ''A Custom theme that it inherits to dispaly the new theme form design
    Inherits MetroFramework.Forms.MetroForm

    Private Sub MetroButton1_Click(sender As Object, e As EventArgs) Handles MetroButton1.Click

        ''Showing the form of the actual game to begin playing
        Game.Show()

        ''Closing of the current window for the game to only be open
        Me.Close()

    End Sub
    Private Sub MetroButton2_Click(sender As Object, e As EventArgs) Handles MetroButton2.Click

        ''instructions on how to actually play the game
        MessageBox.Show("Simply make it to the finish, dont touch the blue walls or you get reset. See how fast you can do it.", "Game Notification", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)

    End Sub
    Private Sub MetroButton3_Click(sender As Object, e As EventArgs) Handles MetroButton3.Click

        ''Shutting down of the entire game
        Me.Close()

    End Sub
End Class