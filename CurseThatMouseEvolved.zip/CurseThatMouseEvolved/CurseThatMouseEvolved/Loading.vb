﻿''Original Owner DeathTheLoner / Lucas Andrews -- LEAVE THIS OR YOU ARE LEECHING ME

Public Class Loading

    ''A Custom theme that it inherits to dispaly the new theme form design
    Inherits MetroFramework.Forms.MetroForm

    Private Sub Loading_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ''The start of the progressbar for the loading screen
        Timer1.Start()

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ''This is how the timer can allow us to use a progress bar to start instantly.
        MetroProgressBar1.Increment(3)

        ''Allowing to exit the loading screen and going to the Main menu of CurseThatMouse // Edit Project Properties and making sure that Shutdown mode is "When last form closes"
        ''Startup form must also be set to the form that has your loading screen with the timer and progress bar.
        If MetroProgressBar1.Value = 100 Then

            ''Showing the main form of the MainMenu of CurseThatMouse
            MainMenu.Show()

            ''Closing the current form of the game.
            Me.Close()

        End If
    End Sub
End Class
