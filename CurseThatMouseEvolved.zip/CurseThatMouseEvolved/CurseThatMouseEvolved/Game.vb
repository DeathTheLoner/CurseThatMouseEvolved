﻿''Original Owner DeathTheLoner / Lucas Andrews -- LEAVE THIS OR YOU ARE LEECHING ME

Public Class Game

    ''A Custom theme that it inherits to dispaly the new theme form design
    Inherits MetroFramework.Forms.MetroForm

    ''The counters for recording the time that it takes for each user.
    Dim counts As Integer
    Dim countm As Integer

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        MoveToStartP1()
        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub P1FINISH_MouseEnter(sender As Object, e As EventArgs) Handles P1FINISH.MouseEnter

        ''Messagebox showing game notifications and also showing the amount of time the user had taken.
        MessageBox.Show("You have finished the Maze.", "CurseThatMouse Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Timer1.Stop()
        MessageBox.Show(countm & " : " & counts, "Game Timer", MessageBoxButtons.OK, MessageBoxIcon.Information)

        ''Opens the main menu again thus also closing the game unless the user wishes to have another attempt
        MainMenu.Show()
        Me.Close()

    End Sub
    Private Sub MoveToStartP1()

        ''This is used for the first level making the walls send you back to the 'start' label.

        ''Instead of refering the Panel1 Location, we have narrowed it and simplifying it to become 'P1'.
        Dim P1 = Panel1.Location

        ''The Location where the mouse will be moved on P1(Panel1).
        P1.Offset(50, 25)

        ''Where the cursor will move if one of the walls are touched by the mouse pointor.
        Cursor.Position = PointToScreen(P1)

    End Sub

    Private Sub P1_MouseEnter(sender As Object, e As EventArgs) Handles Label1.MouseEnter, Label99.MouseEnter, Label98.MouseEnter, Label97.MouseEnter, Label96.MouseEnter, Label95.MouseEnter, Label94.MouseEnter, Label93.MouseEnter, Label92.MouseEnter, Label91.MouseEnter, Label90.MouseEnter, Label9.MouseEnter, Label89.MouseEnter, Label88.MouseEnter, Label87.MouseEnter, Label86.MouseEnter, Label85.MouseEnter, Label84.MouseEnter, Label83.MouseEnter, Label82.MouseEnter, Label81.MouseEnter, Label80.MouseEnter, Label8.MouseEnter, Label79.MouseEnter, Label78.MouseEnter, Label77.MouseEnter, Label76.MouseEnter, Label75.MouseEnter, Label74.MouseEnter, Label73.MouseEnter, Label72.MouseEnter, Label71.MouseEnter, Label70.MouseEnter, Label7.MouseEnter, Label69.MouseEnter, Label68.MouseEnter, Label67.MouseEnter, Label66.MouseEnter, Label65.MouseEnter, Label64.MouseEnter, Label63.MouseEnter, Label62.MouseEnter, Label61.MouseEnter, Label60.MouseEnter, Label6.MouseEnter, Label59.MouseEnter, Label58.MouseEnter, Label57.MouseEnter, Label56.MouseEnter, Label55.MouseEnter, Label54.MouseEnter, Label53.MouseEnter, Label52.MouseEnter, Label51.MouseEnter, Label50.MouseEnter, Label5.MouseEnter, Label49.MouseEnter, Label48.MouseEnter, Label47.MouseEnter, Label46.MouseEnter, Label45.MouseEnter, Label44.MouseEnter, Label43.MouseEnter, Label42.MouseEnter, Label41.MouseEnter, Label40.MouseEnter, Label4.MouseEnter, Label39.MouseEnter, Label38.MouseEnter, Label37.MouseEnter, Label36.MouseEnter, Label35.MouseEnter, Label34.MouseEnter, Label33.MouseEnter, Label32.MouseEnter, Label31.MouseEnter, Label30.MouseEnter, Label3.MouseEnter, Label29.MouseEnter, Label28.MouseEnter, Label27.MouseEnter, Label26.MouseEnter, Label25.MouseEnter, Label24.MouseEnter, Label23.MouseEnter, Label22.MouseEnter, Label21.MouseEnter, Label20.MouseEnter, Label2.MouseEnter, Label19.MouseEnter, Label18.MouseEnter, Label17.MouseEnter, Label16.MouseEnter, Label15.MouseEnter, Label140.MouseEnter, Label14.MouseEnter, Label139.MouseEnter, Label138.MouseEnter, Label137.MouseEnter, Label136.MouseEnter, Label135.MouseEnter, Label134.MouseEnter, Label133.MouseEnter, Label132.MouseEnter, Label131.MouseEnter, Label130.MouseEnter, Label13.MouseEnter, Label129.MouseEnter, Label128.MouseEnter, Label127.MouseEnter, Label126.MouseEnter, Label125.MouseEnter, Label124.MouseEnter, Label123.MouseEnter, Label122.MouseEnter, Label121.MouseEnter, Label120.MouseEnter, Label12.MouseEnter, Label119.MouseEnter, Label118.MouseEnter, Label117.MouseEnter, Label116.MouseEnter, Label115.MouseEnter, Label114.MouseEnter, Label113.MouseEnter, Label112.MouseEnter, Label111.MouseEnter, Label110.MouseEnter, Label11.MouseEnter, Label109.MouseEnter, Label108.MouseEnter, Label107.MouseEnter, Label106.MouseEnter, Label105.MouseEnter, Label104.MouseEnter, Label103.MouseEnter, Label102.MouseEnter, Label101.MouseEnter, Label100.MouseEnter, Label10.MouseEnter, Label141.MouseEnter, Label143.MouseEnter, Label142.MouseEnter, Label147.MouseEnter, Label146.MouseEnter, Label145.MouseEnter, Label144.MouseEnter, Label150.MouseEnter, Label148.MouseEnter

        ''All the labels(Walls) connected to the move to cursor to start function if the mouse touches a wall.
        MoveToStartP1()

        ''This is if you hit a wall when playing the game, it will add 3 seconds to the timer.\
        Timer1.Stop()
        Timer1.Start()

    End Sub



    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

        ''Default position for the mouse to start at once you have enter the tab of the 'LEVEL 1' exactly the same as touching the walls but just when opening 'LEVEL 1'.
        ''It will direct you to 'START' position instantly for you to place the same.
        Dim P1 = Panel1.Location
        P1.Offset(50, 25)
        Cursor.Position = PointToScreen(P1)

        ''Starting the timer displaying your time at the end of the level, how long it took you to complete it.
        Timer1.Start()

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        ''Timer for level 1.
        counts = counts + 1

        ''Adds 1 'm'(minute timer) each time the 's'(second timer) reaches 60.
        If counts = 60 Then
            countm = countm + 1
            counts = counts = 0
        End If

    End Sub
    Private Sub Hover_WallEnter(sender As Object, e As EventArgs) Handles Label99.MouseHover, Label98.MouseHover, Label97.MouseHover, Label96.MouseHover, Label95.MouseHover, Label94.MouseHover, Label93.MouseHover, Label92.MouseHover, Label91.MouseHover, Label90.MouseHover, Label9.MouseHover, Label89.MouseHover, Label88.MouseHover, Label87.MouseHover, Label86.MouseHover, Label85.MouseHover, Label84.MouseHover, Label83.MouseHover, Label82.MouseHover, Label81.MouseHover, Label80.MouseHover, Label8.MouseHover, Label79.MouseHover, Label78.MouseHover, Label77.MouseHover, Label76.MouseHover, Label75.MouseHover, Label74.MouseHover, Label73.MouseHover, Label72.MouseHover, Label71.MouseHover, Label70.MouseHover, Label7.MouseHover, Label69.MouseHover, Label68.MouseHover, Label67.MouseHover, Label66.MouseHover, Label65.MouseHover, Label64.MouseHover, Label63.MouseHover, Label62.MouseHover, Label61.MouseHover, Label60.MouseHover, Label6.MouseHover, Label59.MouseHover, Label58.MouseHover, Label57.MouseHover, Label56.MouseHover, Label55.MouseHover, Label54.MouseHover, Label53.MouseHover, Label52.MouseHover, Label51.MouseHover, Label50.MouseHover, Label5.MouseHover, Label49.MouseHover, Label48.MouseHover, Label47.MouseHover, Label46.MouseHover, Label45.MouseHover, Label44.MouseHover, Label43.MouseHover, Label42.MouseHover, Label41.MouseHover, Label40.MouseHover, Label4.MouseHover, Label39.MouseHover, Label38.MouseHover, Label37.MouseHover, Label36.MouseHover, Label35.MouseHover, Label34.MouseHover, Label33.MouseHover, Label32.MouseHover, Label31.MouseHover, Label30.MouseHover, Label3.MouseHover, Label29.MouseHover, Label28.MouseHover, Label27.MouseHover, Label26.MouseHover, Label25.MouseHover, Label24.MouseHover, Label23.MouseHover, Label22.MouseHover, Label21.MouseHover, Label20.MouseHover, Label2.MouseHover, Label19.MouseHover, Label18.MouseHover, Label17.MouseHover, Label16.MouseHover, Label150.MouseHover, Label15.MouseHover, Label149.MouseHover, Label148.MouseHover, Label146.MouseHover, Label145.MouseHover, Label144.MouseHover, Label143.MouseHover, Label142.MouseHover, Label141.MouseHover, Label140.MouseHover, Label14.MouseHover, Label139.MouseHover, Label138.MouseHover, Label137.MouseHover, Label136.MouseHover, Label135.MouseHover, Label134.MouseHover, Label133.MouseHover, Label132.MouseHover, Label131.MouseHover, Label130.MouseHover, Label13.MouseHover, Label129.MouseHover, Label128.MouseHover, Label127.MouseHover, Label126.MouseHover, Label125.MouseHover, Label124.MouseHover, Label123.MouseHover, Label122.MouseHover, Label121.MouseHover, Label120.MouseHover, Label12.MouseHover, Label119.MouseHover, Label118.MouseHover, Label117.MouseHover, Label116.MouseHover, Label115.MouseHover, Label114.MouseHover, Label113.MouseHover, Label112.MouseHover, Label111.MouseHover, Label110.MouseHover, Label11.MouseHover, Label109.MouseHover, Label108.MouseHover, Label107.MouseHover, Label106.MouseHover, Label105.MouseHover, Label104.MouseHover, Label103.MouseHover, Label102.MouseHover, Label101.MouseHover, Label100.MouseHover, Label10.MouseHover, Label1.MouseHover

        ''All the labels(Walls) connected to the move to cursor to start function if the mouse touches a wall.
        MoveToStartP1()

        ''This is if you hit a wall when playing the game, it will add 3 seconds to the timer.
        Timer1.Stop()
        Timer1.Start()

    End Sub
End Class
